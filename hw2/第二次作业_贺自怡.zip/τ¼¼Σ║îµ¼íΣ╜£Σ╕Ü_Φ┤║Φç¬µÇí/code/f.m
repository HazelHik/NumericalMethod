function output = f(x)
output = exp(x)-2-cos(exp(x)-2);
end